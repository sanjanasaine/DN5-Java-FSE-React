public class ExcelDocument implements Document {

    @Override
    public void create() {

        System.out.println("Excel document has been created successfully.");

    }
}