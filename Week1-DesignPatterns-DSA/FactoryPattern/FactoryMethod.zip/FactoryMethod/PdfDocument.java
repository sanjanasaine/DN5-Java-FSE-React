public class PdfDocument implements Document {

    @Override
    public void create() {

        System.out.println("PDF document has been created successfully.");

    }
}